# samples

if you have a sample please feel free to send a pull request.

also the tests are very concise and helpful. 

i would recommend taking a peek.